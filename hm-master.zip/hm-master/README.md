# hm
Codded By Muhammad Hamza



This Is For Educational Purposes Only 

Im Not Responsible For Any Illegal Use 

If U Need Any Help You Can Contact Me On Whatsappp : +923909-7992202

Pakistani Hacker And Codder

#commands

1-pkg update && pkg upgrade

2-pkg install python

3-pkg install python2

4-pkg install git

5-git clone https://github.com/Hamzahash/hm.git

6-pip2 install requests

7-pip2 install mechanize

8-ls

9-cd hm

10-python2 hm.py

-------------------------------------------------------------------

                           PROUD TO BE A MUSLIM

                          PROUD TO BE A PAKISTANI

--------------------------------------------------------------------

                  HAMZA THE OFFICIAL PROGRAMMER [ H.O.P ]

--------------------------------------------------------------------

          EDITING MY SCRIPT WILL NOT MAKE YOU A MASTER OF CODING

                      My Facebook Id : Muhammad Hamza

                       TRUST IN ALLAH DONT LOOSE HOPE

---------------------------------------------------------------------

                             لآ اِلَهَ اِلّا اللّهُ مُحَمَّدٌ رَسُوُل    

               Laaa Ilaaha Illa-llaahu Muhammadur-Rasoolu-llaah

      There is no God but Allah Muhammad is the Messenger of Allah

----------------------------------------------------------------------
